# Oque é matemática
Descarte> A matemática é a mais confiável de todas as ciências

## Axioma

## Prova matemática

## Postulado


## Teorema


#_Cálculo 