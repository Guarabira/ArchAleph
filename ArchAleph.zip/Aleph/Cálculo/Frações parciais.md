Teoria sobre como resolver problemas com frações parciais, onde uma fração grande é dividida em varias frações menores.
![[Frações_Parciais.pdf]]

E abaixo temos alguns exemplos resolvidos:


#_Cálculo
