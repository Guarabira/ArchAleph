"Uma boa notação possui uma engenhosidade e uma sugestividade que, às vezes, a faz
parecer com um professor de verdade" Bertrand Russell (1872-1970)


Na matemática, uma notação é um conjunto de símbolos que representam uma ideia. Essas notações devem, a medida do possível, usar símbolos consagrados e universalmente aceitos, além de passar a sua mensagem de forma mais clara e simples possível.

## Notações generalistas

| Símbolo           | Significado                                               |
| ----------------- | --------------------------------------------------------- |
| $\rightarrow$     | Acarreta em                                               |
| $\leftrightarrow$ | Se, e somente se; Equivalente (no<br>caso de proposições) |
| >                 | Maior que                                                 |
| <                 | Menor que                                                 |
| $\approx$         | Aproximadamente                                           |
| $\geq$            | Maior ou igual                                            |
| $\leq$            | Menor ou igual                                            |
| $\cong$           | Congruente                                                |
| $\forall$         | Para todo; Qualquer que seja;                             |
| $\exists$         | Existe um                                                 |
| $\exists$!        | Existe um único                                           |
| $\pm$             | Mais ou menos                                             |
| ; \|              | Tal que                                                   |
| $\therefore$      | Portanto                                                  |

## Notações de conjuntos numéricos
| Símbolo      | Conjunto           |
| ------------ | ------------------ |
| $\mathbb{N}$ | Números naturais   |
| $\mathbb{Z}$ | Números inteiros   |
| $\mathbb{Q}$ | Números racionais  |
| $\mathbb{R}$ | Números reais      |
| $\mathbb{C}$ | Números complexos  |
| $\mathbb{A}$ | Números algébricos |
| $\in$        | Pertence           |
| $\notin$     | Não pertence       |
| $\subset$    | Está contido       |
| $\cup$       | União              |
| $\cap$       | Interseção         |
## Letras gregas
| Minúscula  | Maiúscula  | Nome    |
| ---------- | ---------- | ------- |
| $\alpha$   | $A$        | Alfa    |
| $\beta$    | $B$        | Beta    |
| $\gamma$   | $\Gamma$   | Gama    |
| $\delta$   | $\Delta$   | Delta   |
| $\epsilon$ | $E$        | Épsilon |
| $\zeta$    | $Z$        | Zeta    |
| $\eta$     | $H$        | Eta     |
| $\theta$   | $\Theta$   | Teta    |
| $\iota$    | $I$        | Iota    |
| $\kappa$   | $K$        | Capa    |
| $\lambda$  | $\Lambda$  | Lambda  |
| $\mu$      | $M$        | Mu      |
| $\nu$      | $N$        | Nu      |
| $\xi$      | $\Xi$      | Xi      |
| $\omicron$ | $O$        | Ômicron |
| $\pi$      | $\Pi$      | Pi      |
| $\rho$     | $P$        | Rho     |
| $\sigma$   | $\Sigma$   | Sigma   |
| $\tau$     | $T$        | Tau     |
| $\upsilon$ | $\Upsilon$ | Upsilon |
| $\phi$     | $\Phi$     | Phi     |
| $\chi$     | $X$        | Chi     |
| $\phi$     | $\Psi$     | Psi     |
| $\omega$   | $\Omega$   | Omega   |
| $\aleph$   |            | Aleph   |
## Símbolos do cálculo

Infinito
$$\infty$$

#_Cálculo 