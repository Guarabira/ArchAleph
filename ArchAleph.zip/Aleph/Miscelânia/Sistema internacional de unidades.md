
| Grandeza    | Unidade |
| ----------- | ------- |
| Comprimento | m       |
| Massa       | Kg      |
| tempo       | s       |

#_Generalista 