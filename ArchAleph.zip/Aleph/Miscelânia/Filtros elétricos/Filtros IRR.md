Os dispositivos digitais são elementos cada vez mais presentes no nosso cotidiano, e eles operam por meio da transmissão e do processamento de sinais, que são representações de fenômenos físicos ou virtuais.Em muitas ocasiões, esses sinais costumam apresentar distorções provenientes de ruídos eletromagnéticos, e demandam o uso de filtros para remover os sinais indesejados. 

Um dos tipos de filtro usado para esse fim, são os filtros IIR(Infinite impulse response). Ele depende de entradas e saídas passadas, e da amostra presente para definir sua saída atual .Dessa forma, ele pode ser compreendido como um sistema com memória e realimentação. Portanto exige preocupações com respeito a sua estabilidade.

De forma análoga aos filtros analógicos, os filtros digitais também tem nomes específicos de acordo com seu desempenho: ele pode ser passa alta, passa baixa.

- Transformada Z
- memória e realimentação

Preocupação com estabilidade

Depende de amostras atuais e anteriores da entrada e da saída(realimentação)

taps

# Topologia
A topologia é dividida em duas partes, uma é chamada de feedback e a outra de feedforward

4 estruturas equivalentes

# Projetos

Há três métodos principais para projetar filtros IIR: aproximação
das derivadas da equação diferencial, invariância ao impulso e
transformação bilinear, sendo esta última mais popular. Apesar de causar distorção no eixo das frequências, o método da transformação bilinear é o mais indicado para projetar um filtro digital a partir de um analógico.

1. Método de invariância ao impulso

Envolve usar funções de transferência de filtros analógicos para depois discredizr por amostragem

2. Transformada bilinear
# Usos

