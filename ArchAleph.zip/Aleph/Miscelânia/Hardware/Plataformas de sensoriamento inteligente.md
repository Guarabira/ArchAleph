IOT
5G
Metrologia
Contínuo cyber físico
# Camadas tecnológicas
- Componentes físicos
- Componentes de conectividade
- Aplicação de infraestrutura
- Segurança de informação