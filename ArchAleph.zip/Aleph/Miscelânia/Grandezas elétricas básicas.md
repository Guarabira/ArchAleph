
# Corrente

# Tensão

# Resistência



#_Generalista
