É comum escolher a tensão e a potência como referência, e calcular as outras grandezas do sistema em função delas.

$$Valor em pu=\frac{Valor normal}{Valor de base}$$
# Tensão
$$Vpu=\frac{V}{Vb}$$
# Potência aparente
$$Spu=\frac{S}{Sb}$$
# Corrente
$$Ib=\frac{Sb}{Vb}$$
# Impedância

$$Zb=\frac{Vb²}{Sb}=\frac{Vb}{Ib}$$
# Sistemas trifásicos
Como sistemas trifásicos podem estar arranjados em $\Delta$ ou Y,  é preciso colocar tudo em Y e usar o diagrama unifilar para representar as 3 fases com apenas uma.

![[Trifásico pu.png]]

$$Sbase3\phi=3Sb1\phi$$
$$Vb=\sqrt{3}Vbfase$$
$$Ib=\frac{Sbase}{\sqrt{3}Vbase}$$
$$Zbase=\frac{Vbf}{Ibf}$$
# Mudança de base

Devido à existência dos transformadores, existem muitas situações onde é necessário trocar o valor pu de uma base para outra.

$$Zpunovo=Zpuvelho*(\frac{Vbvelha}{Vbnova})²\frac{Sbnovo}{Sbvelho}$$

