Usinas termoelétricas são grandes construções que geram energia elétrica por meio de reações térmicas, onde a água é aquecida por meio de algum combustível, e seu vapor alimenta uma caldeira, gerando eletricidade. Os combustíveis para esse tipo de usina costumam ser não renováveis, como carvão,petróleo e gás natural.



# Vantagens
- Baixo custo inicial
- Disponibilidade de combustíveis variados
- Não requer uma localização específica
- Fornece uma energia estável e constante, sem depender de fatores externos
- Rápido tempo de construção
# Desvantagens

- Poluição da atmosfera com gases do efeito estufa(Usinas nucleares são uma exceção)
- Usa energia não renovável
- Baixa eficiência em comparação com outras fontes
- Impactos ambientais envolvidos na extração do combustível
- Consumo de água
- 
# Tipos de combustão
## Interna
Considera-se como combustão interna, o equipamento (turbina ou motor) que utiliza os próprios gases que surgem internamento no equipamento durante a queima do combustível (combustão), como fluido de trabalho. Esses gases realizam
os processos de compressão, aumento de temperatura,expansão e por fim, exaustão;

Comumente, denomina-se esse tipo de equipamento comoturbina ou motor de explosão.
Ex: O motor automobislístico

## Externa

Considera-se um equipamento de combustão externa (turbina ou motor) aquele cujos gases de combustão que realizam os processos termodinâmicos, e por conseguinte, trabalho, ocorre externamente. Basicamente, as usinas termoelétricas, com raras exceções, apresentam combustão externa, pois, em geral, são mais eficientes;
# Tipos de termoelétricas

## Usinas à vapor

## Usinas à diesel

## Usinas à gás

## Usinas termonucleares

#_Potência 