![[Física dos diodos.pdf]]

#_Eletrônica 