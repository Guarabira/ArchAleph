Termodinâmica é o ramo da física que estuda as operações da energia térmica.

# Leis da termodinâmica

## Lei zero
Em um sistema com vários
## Primeira lei
A energia não é criada ou destruída, ela apenas é transformada. A energia total em um sistema isolado permanece constante ao longo do tempo. A energia pode mudar de uma forma para outra em um sistema fechado, mas a quantidade total de energia permanece a mesma.
## Segunda lei
O calor flui naturalmente de um corpo de temperatura mais alto para um corpo de temperatura mais baixo, e nunca o contrário, quando nenhum trabalho é feito. Além disso, a entropia de um sistema isolado sempre aumenta durante processos irreversíveis.
## Terceira lei
É impossível atingir a temperatura do zero absoluto em um número finito de etapas. À medida que a temperatura de um sistema se aproxima do zero absoluto, sua entropia também se aproxima de um valor mínimo finito.

# Temperatura

#  Sistemas termodinâmicos

## Propriedades intensivas

## Propriedades extensivas

## Processos

Um processo termodinâmico é definido pelas mudanças que sistema
### Isotérmico(Temperatura constante)
### Isobárico(Pressão constante)
### Isocórico(Volume constante)

## Ciclo
Um sistema executa um ciclo quando ele executa um ou mais processos e depois retorna ao seu estado inicial.

# Conservação de energia

$$\Delta E$$
# Calor específico



#_Física 