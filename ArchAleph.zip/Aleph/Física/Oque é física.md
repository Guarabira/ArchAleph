Física é a ciência que estuda as forças básicas da natureza e do corpos.
#_Física 
