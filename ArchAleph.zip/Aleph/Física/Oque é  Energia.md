A energia é um dos conceitos mais difícil na física, ela pode ser definida como *a capacidade de um sistema de realizar trabalho* 

# Formas de energia
- Mecânica
- Elétrica
- Química
- Luminoso
- Gravitacional
- Nuclear
- Magnética
- Térmica


#_Física 
