
# Variáveis básicas
## Posição angular
$$\theta$$
## Velocidade angular

$$\omega=\frac{d\theta}{dt}$$
A velocidade angular pode ser escrita em radianos por segundo, ou em rotações por minuto(RPM). A equação abaixo pode ser usada para converter RPM em radianos por segundo.
$$\frac{V(rpm)*2\pi}{60s}=\omega$$


## Aceleração angular
$$a=\frac{d\omega}{dt}=\frac{d^2\theta}{dt^2}$$
## Torque
$$\tau=F*r*\sin(\theta)$$

# 2º Lei de Newton no movimento rotacional

## Momento de inércia

Representado pela letra J, o momento de inércia representa o quão difícil é girar um objeto. Sua unidade é o $kg/m^2$


$$J=\int_{c}^{} r^2 \, dm$$

$$\tau=J\frac{d\omega}{dt}=J\frac{d^2\theta}{dt^2}=Ja$$
## Trabalho
$$W=\tau\theta$$
## Potência
$$P=\tau\omega$$

1hp=746watts


#_Física