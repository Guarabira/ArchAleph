Além da função de transferência no domínio s de Laplace, existe uma segunda forma de representar o comportamento de um sistema, que é pelo domínio do tempo, usando equações de espaço de estados.




$$\dot{x}=Ax +Bu
$$
$$\dot{y}=Cx+Du
$$
x $\rightarrow$ Vetor de estado
$\dot{x}\rightarrow$  Derivada do vetor de estado com relação ao tempo

y $\rightarrow$ Vetor de saída
$\dot{y}\rightarrow$  Derivada do vetor de saída com relação ao tempo
u $\rightarrow$ Vetor de entrada
A $\rightarrow$ Matriz do sistema
B $\rightarrow$ Matriz de entrada
C $\rightarrow$ Matriz de saída
D $\rightarrow$ Matriz de transmissão direta

# Convertendo uma função de transferência para equação de espaço de estados

