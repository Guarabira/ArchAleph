# Polos e zeros

Polos: São valores na função de transferência que fazem com que  ela seja indeterminada no denominador.

Zeros: São valores de s onde a função de transferência do numerador é zerada
$$\frac{s+2}{s+5}$$

Na função de transferência acima, observamos que:

Zero s= -2
Polo  s=-5

# Resposta de 1º grau

Considerando que o sistema anterior seja submetido a entrada da função degrau: 

Degrau:   $$\frac{1}{s}$$

Sistema: $$\frac{s+2}{s+5}$$

Saída do sistema:$$\frac{s+2}{s(s+5)}=\frac{A}{s}+\frac{B}{s+5}=\frac{2/5}{s}+\frac{3/5}{s+5}$$
Passando para o domínio do tempo:$$c(t)=\frac{2}{5}+\frac{3}{5}e^{-5t}$$
Desse modo, é possível concluir que:
1. Um polo na esquerda gera uma resposta transitório $e^{-at}$ onde a é o ponto no eixo real onde está o polo.
2. Um polo na entrada gera uma resposta forçada.

# Atributos de um sistema de 1º ordem
$$1-e^{-at}$$

## Constante de tempo
$$\tau=\frac{1}{a}$$
É o tempo necessário para a resposta ao degrau atingir 63% do seu valor final
## Tempo de subida
O tempo necessário para que a resposta vá de 0.1 até 0.9 do seu valor final 
$$Tr=\frac{2.2}{a}$$

## Tempo de acomodação
É definido como o tempo em que a resposta alcança a faixa de 2% do seu valor final
$$Ts=\frac{4}{a}$$

# Sistema de 2° ordem

## Tipos de resposta

### Superamortecido

### Subamortecido

### Não amortecido

### Criticamente amortecido


## Fator de amortecimento

$$\zeta=$$
## Frequência natural

$$\omega=$$

## Tempo de acomodação

$$Ts=\frac{- ln(0.02*\sqrt{1-\zeta^2})}{\zeta\omega}$$




#_Controle 
