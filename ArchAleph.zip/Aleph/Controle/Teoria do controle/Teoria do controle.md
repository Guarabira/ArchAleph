# Oque é controle

[[Controle.canvas|Controle]]

# H

## H2

### H3

#### H4




#_Controle 
