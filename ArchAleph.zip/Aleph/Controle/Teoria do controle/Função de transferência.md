As funções de transferências são ferramentas matemáticas que descrevem o comportamento de um sistema no domínio da frequência(s). Elas se resumem a uma fração de duas funções, onde o numerador é a saída e o numerador é a entrada. As vezes, uma função de transferência precisa ser decomposta por técnicas de [[Frações parciais|frações parciais]]

$$H(s)=\frac{C(s)}{R(s)}$$
Para colocar essas equações no domínio de s para o tempo, ou vice versa, é imprescindível o domínio da transformada de Laplace. Abaixo, está um exemplo onde algumas funções no domínio do tempo estão sendo representadas pela forma em frequência.
$$ F(s) = \mathcal{L}\{f(t)\} = \int_{0}^{\infty} e^{-st} f(t) \, dt $$

$$\delta(t)\rightarrow1$$
$$u(t)\rightarrow\frac{1}{s}$$
$$t*u(t)\rightarrow\frac{1}{s²}$$

$$t^nu(t)\rightarrow\frac{n!}{s^n+1}$$
$$e^{-at}\rightarrow\frac{1}{s+a}$$
$$sen(t)u(t)\rightarrow\frac{w}{s²+w²}$$
$$cos(t)u(t)\rightarrow\frac{s}{s²+w²}$$

# Funções de transferência de circuitos

Cada componente passivo pode ser simplificado para o domínio s por meio de sua impedância.
$$Resistor\rightarrow R$$
$$Capacitor\rightarrow \frac{1}{Cs}$$
$$Indutor\rightarrow Ls$$
# Sistemas mecânicos
Os sistemas mecânicos podem ser modelados como se fossem impedâncias de um circuito em série.
#_Controle 