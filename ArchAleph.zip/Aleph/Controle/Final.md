G1=zpk(0,[5 10],10)
tf 12,poly
1/s+1
feedback(G1xG2,G3)


3.
s(s+5)(s+1) pid

kr?e pcr?