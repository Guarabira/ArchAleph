![[Cérebro no pote.png]]
	O projeto Aleph é uma iniciativa pessoal sem fins lucrativos que tem como objetivo usar obsidian para registrar e sistematizar todas as cadeiras do curso de engenharia elétrica da UFPB. O conteúdo desses documentos tem caráter resumido, para ser usado como uma rápida revisão, logo, continua sendo de extrema importância a leitura de livros mais aprofundados.

# Introdução à engenharia elétrica







#_Generalista 