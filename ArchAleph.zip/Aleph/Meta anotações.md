
dois \$ Significa uma equação ou símbolo junto com  as outras letras
Quatro \$ significa uma equação que ocupa uma linha inteira


Código hexadecimal de background:#212437

![[3-1545634901.gif]]

#_Obsidian

